public class RectangleDrawerAdapter implements RectangleDrawer {
    private RectangleRenderer adaptee;
    public RectangleDrawerAdapter(RectangleRenderer adaptee) {
        this.adaptee = adaptee;
    }
    public void draw(Point topLeft, Point bottomRight) {
        int x1 = topLeft.getX();
        int y1 = topLeft.getY();
        int x2 = bottomRight.getX();
        int y2 = bottomRight.getY();
        adaptee.render(Math.min(x1,x2),Math.min(y1,y2),Math.abs(x2-x1),Math.abs(y2-y1));
    }
}